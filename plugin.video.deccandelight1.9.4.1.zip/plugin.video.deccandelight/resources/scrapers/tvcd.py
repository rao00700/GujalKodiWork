'''
thiruttuvcd deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib
import re
import requests
import HTMLParser


class tvcd(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.thiruttuvcd.stream/genre/'
        self.icon = self.ipath + 'tvcd.png'
        self.list = {'01Tamil Movies': self.bu + 'tamil-movies/',
                     '02Telugu Movies': self.bu + 'telugu-movies/',
                     '03Malayalam Movies': self.bu + 'malayalam-movies/',
                     '05Hindi Movies': self.bu + 'bollywood-movies/',
                     '06Tamil Dubbed Movies': self.bu + 'tamil-dubbed-movies/',
                     '07Telugu Dubbed Movies': self.bu + 'telugu-dubbed-movies/',
                     '08Hindi Dubbed Movies': self.bu + 'hindi-dubbed-movies/',
                     '09English Movies': self.bu + 'hollywood-movies/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-6] + '?s='}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_items(self, url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Thiruttu VCD')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'nag cf'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'wp-pagenavi'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('div', {'id': re.compile('^post-')})

        for item in items:
            title = h.unescape(item.find('h2').text)
            title = self.clean_title(title)
            url = item.find('a')['href']
            tdiv = item.find('img')
            if 'src=' in str(tdiv):
                thumb = tdiv.get('src').encode('utf8')
            elif 'data-original=' in str(tdiv):
                thumb = tdiv.get('data-original').encode('utf8')
            else:
                thumb = self.icon
            movies.append((title, thumb, url))

        if '"next"' in str(Paginator):
            purl = Paginator.find('a', {'class': 'nextpostslink'}).get('href')
            pgtxt = Paginator.find('span', {'class': 'pages'}).text
            title = 'Next Page.. (Currently in {0})'.format(pgtxt)
            movies.append((title, self.nicon, purl))

        return (movies, 8)

    def get_videos(self, url):
        videos = []

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('ul', {'class': 'tab-content'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('iframe')
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl, videos)
        except:
            pass

        return videos
