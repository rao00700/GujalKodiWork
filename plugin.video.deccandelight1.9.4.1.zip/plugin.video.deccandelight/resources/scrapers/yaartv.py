'''
yaartv deccandelight plugin
Copyright (C) 2018 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urlparse, re, requests
import HTMLParser
import xbmcgui

class yaartv(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://tvyaar.cc/'
        self.icon = self.ipath + 'yaartv.png'
            
    def get_menu(self):
        mlist = {}
        html = requests.get(self.bu, headers=self.hdr).text
        navmenu = re.findall(r'<div\s*id="nav">(.+?)</div>', html, re.DOTALL)[0]
        mdiv = BeautifulSoup(navmenu)
        items = mdiv.findAll('li', {'class':''})
        ino = 1
        for item in items:
            mlist['%02d%s'%(ino,item.text)]=item.find('a')['href']
            ino += 1
        return (mlist,5,self.icon)

    def get_second(self,iurl):
        """
        Get the list of shows.
        :return: list
        """
        shows = []
        h = HTMLParser.HTMLParser()

        html = requests.get(iurl, headers=self.hdr).text
        smenu = re.findall(r'"tabcontent".+?cont">(.*?)<div class="clear">', html, re.DOTALL)[0]
        mdiv = BeautifulSoup(smenu)
        items = mdiv.findAll('div', {'class': re.compile('^four-col')})
        for item in items:
            title = h.unescape(item.find('a', {'class': 'serial_title'}).text)
            thumb = item.find('a', {'class': 'serial_img'}).find('img')['src']
            url = item.find('a', {'class': 'serial_title'}).get('href')
            shows.append((title.encode('utf8'), thumb, url.encode('utf8')))

        return (shows,7)
        
    def get_items(self,iurl):
        episodes = []
        parts = iurl.split('/')
        parts[-1] = 'episodes/' + parts[-1]
        iurl = '/'.join(parts)
        html = requests.get(iurl, headers=self.hdr).text
        thumb = re.findall(r'<img\s*src="([^"]+)', html, re.DOTALL)[0]
        html = re.findall('class="full_episode".+?(<ul>.*?</ul>)', html, re.DOTALL)[0]
        mdiv = BeautifulSoup(html)
        items = mdiv.findAll('li')
        for item in items:
            title = item.find('div', {'class': 'episode_date'}).text
            title += u' - {}'.format(item.find('div', {'class': 'episode_link'}).text)
            url = item.find('div', {'class': 'episode_link'}).find('a')['href']
            episodes.append((title, thumb, url))
        return (episodes,8) 

    def get_videos(self,iurl):
        videos = []
        html = requests.get(iurl, headers=self.hdr).text
        html = re.findall('download_link1[^>]+>(.*?)<div class="clear"></div>', html, re.DOTALL)[0]
        mdiv = BeautifulSoup(html)
        items = mdiv.findAll('a')
        prog_per = 0
        numlink = 0
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Deccan Delight', 'Processing Links...')
        for item in items:
            vid_link = item.get('href') + '|Referer=' + self.bu
            self.resolve_media(vid_link,videos)
            prog_per += 100/len(items)
            numlink += 1
            if (pDialog.iscanceled()): return videos
            pDialog.update(prog_per, 'Collected Links... %s from %s'%(len(videos),len(items)))
        return videos
